===============INSTRUCTIONS=============== v1

Just copy your video files with embedded subtitle to this folder and drop them on extractor.bat. Your subtitles will export with a .text extension.

You can then visualise and convert the files into other formats here: http://djitelemetryoverlay.com

Let me know if it does not work for your files. This has not been thoroughly tested.

app@prototyping.barcelona

===============ATTRIBUTION===============

######## This software uses mp4Box. See license in bin folder ########